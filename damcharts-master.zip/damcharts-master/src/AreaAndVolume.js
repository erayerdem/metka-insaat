import React, { Component } from 'react'

export default class AreaAndVolume extends Component {
  render() {
    return (
      <div>
        <h1>
            Hello World</h1>      </div>
    )
  }
}
